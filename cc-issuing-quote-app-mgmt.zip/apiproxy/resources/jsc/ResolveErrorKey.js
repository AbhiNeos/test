/**
 * ResolveErrorKey.js
 * Credit Card Issuing Quote and Application Management  (cc-issuing-quote-app-mgmt)
 *
 * Builds the KVM lookup key (and optional substitution value) consumed by the
 * SF-ErrorHandling shared flow.
 *
 * Outputs:
 *   custom.kvm.key      - KVM key:  AMZ_ARW_<apiproxy.name>_<SUFFIX>
 *   custom.kvm.status   - HTTP status returned to the consumer
 *   custom.kvm.resolved - always true (generic fallback keys always exist in the KVM)
 *   custom.error.value  - OPTIONAL single value substituted into "errorvalue1"
 *
 * ---------------------------------------------------------------------------
 * PLATFORM ERROR MAPPING
 *   403 (by status code)      -> _403                        status 403
 *   401 (one shared key, errorvalue1 differs per scenario):
 *        invalid/expired token -> _401 + "InvalidExpiredToken"  status 401
 *        missing credentials   -> _401 + "MissingCredentials"   status 401
 *        any other 401         -> _401 + "OauthIssue"           status 401
 *   OAS validation (any)      -> _400                        status 400
 *   Quota / rate limit        -> _429                        status 429
 *   Fallback                  -> _500                        status 500
 *
 * BACKEND ERROR MAPPING  (fault.name = "ErrorResponseCode")
 *   backend 401 -> _BE_401_500   status 500
 *   backend 500 -> _BE_500_500   status 500
 *   backend 403 -> _BE_403_403   status 403
 *   fallback    -> _BE_500       status 500
 * ---------------------------------------------------------------------------
 */

// ===========================================================================
// CONFIG
// ===========================================================================

var PREFIX = "AMZ_ARW";

// Backend status -> mapped (client-facing) status.
// Anything not listed here uses the fixed fallback key _BE_500 (status 500).
var BACKEND_STATUS_MAP = {
    401: 500,
    500: 500,
    403: 403
};

// ===========================================================================
// Read Apigee error context
// ===========================================================================

var proxyName       = context.getVariable("apiproxy.name")     || "unknown";
var rawFaultName    = context.getVariable("fault.name")        || "";
var errorMessage    = context.getVariable("error.message")     || "";
var errorStatusCode = parseInt(context.getVariable("error.status.code") || "500", 10);

// OAS policy variables (policy is named OAS-Validate in this proxy)
var oasFaultCause = context.getVariable("OASValidation.OAS-Validate.fault.cause") || "";
var oasFailed     = context.getVariable("OASValidation.OAS-Validate.failed");

// ===========================================================================
// Helpers
// ===========================================================================

function setKey(suffix, status) {
    context.setVariable("custom.kvm.key", PREFIX + "_" + proxyName + "_" + suffix);
    context.setVariable("custom.kvm.status", String(status));
    context.setVariable("custom.kvm.resolved", true);
}

// Single-value substitution: replaces "errorvalue1" in the KVM template.
// (Two-value form would be setValue(v1, v2) -> "v1||v2"; not needed here.)
function setValue(v1, v2) {
    var combined = (v2 === undefined || v2 === null) ? String(v1) : (String(v1) + "||" + String(v2));
    context.setVariable("custom.error.value", combined);
}

// RaiseFault hides the real policy name inside error.message
var faultName = rawFaultName;
if (rawFaultName === "RaiseFault" && errorMessage.indexOf("Fault name : ") !== -1) {
    faultName = errorMessage.split("Fault name : ")[1].trim();
}

// Normalise OAS detection (fault.name at proxy level is too generic)
var isOAS = (oasFailed === true || oasFailed === "true" || oasFaultCause !== "");

var handled = false;

// ===========================================================================
// 1. BACKEND ERRORS  (fault.name = "ErrorResponseCode")
// ===========================================================================

if (faultName === "ErrorResponseCode") {
    var backendStatus = errorStatusCode;
    if (BACKEND_STATUS_MAP.hasOwnProperty(backendStatus)) {
        var mappedStatus = BACKEND_STATUS_MAP[backendStatus];
        setKey("BE_" + backendStatus + "_" + mappedStatus, mappedStatus);
    } else {
        setKey("BE_500", 500);   // fixed backend fallback
    }
    handled = true;
}

// ===========================================================================
// 2. PLATFORM: 403 BY STATUS CODE
// ===========================================================================

if (!handled && errorStatusCode === 403) {
    setKey("403", 403);
    handled = true;
}

// ===========================================================================
// 3. PLATFORM: 401 SCENARIOS
//    One shared key (_401); errorvalue1 differs per scenario.
// ===========================================================================

if (!handled) {
    switch (faultName) {

        // --- (a) invalid or expired token ---
        case "RF-InvalidExpiredToken":
        case "InvalidAccessToken":
        case "invalid_access_token":
        case "access_token_expired":
        case "TokenExpired":
        case "InvalidJWT":
        case "JWSVerificationFailed":
            setKey("401", 401);
            setValue("InvalidExpiredToken");
            handled = true;
            break;

        // --- (b) missing credentials in the header ---
        case "RF-MissingCredentials":
        case "FailedToResolveAccessToken":
        case "FailedToResolveToken":
        case "FailedToResolveAPIKey":
        case "MissingCredentials":
            setKey("401", 401);
            setValue("MissingCredentials");
            handled = true;
            break;

        // --- (c) any other OAuth / 401 issue ---
        case "RF-OauthIssue":
        case "InvalidApiKey":
        case "FailedToResolveAuthorizationCode":
        case "InvalidClaim":
        case "FailedToResolveClaim":
        case "BadJOSEHeader":
        case "AlgorithmNotAllowed":
        case "DecryptionFailed":
        case "JWEDecryptionFailed":
        case "InvalidOperation":
            setKey("401", 401);
            setValue("OauthIssue");
            handled = true;
            break;

        default:
            break;
    }
}

// Catch-all for any remaining 401 status not matched by fault name above
if (!handled && errorStatusCode === 401) {
    setKey("401", 401);
    setValue("OauthIssue");
    handled = true;
}

// ===========================================================================
// 4. PLATFORM: OAS VALIDATION -> always 400
// ===========================================================================

if (!handled && isOAS) {
    setKey("400", 400);
    handled = true;
}

// ===========================================================================
// 5. PLATFORM: QUOTA / RATE LIMIT -> always 429
// ===========================================================================

if (!handled) {
    switch (faultName) {
        case "QuotaViolation":
        case "SpikeArrestViolation":
        case "InvalidMessageWeight":
        case "InvalidQuotaInterval":
        case "InvalidQuotaTimeUnit":
        case "FailedToResolveQuotaIntervalReference":
        case "FailedToResolveQuotaIntervalTimeUnitReference":
        case "FailedToResolveSpikeArrestRate":
            setKey("429", 429);
            handled = true;
            break;
        default:
            break;
    }
}

// Also catch a raw 429 status
if (!handled && errorStatusCode === 429) {
    setKey("429", 429);
    handled = true;
}

// ===========================================================================
// 6. PLATFORM FALLBACK -> 500
// ===========================================================================

if (!handled) {
    setKey("500", 500);
}
