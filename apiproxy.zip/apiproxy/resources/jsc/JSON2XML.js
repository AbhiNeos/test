// JSON2XML.js
// Converts JSON (from request body) into XML and sets it as the response
// Ported from Akana's Freemarker/JS-based JSON2XML utility

function JSON2XML(json) {
    var encStr = '<?xml version="1.0" encoding="UTF-8"?>';
    var obj = JSON.parse(json);
    var xml = transform2XML(obj);
    return encStr + xml;
}

function transform2XML(o) {
    if (typeof o == 'object' && o.constructor == Object && checkLength(o) == 1) {
        for (var a in o) {
            return convert(a, o[a]);
        }
    } else {
        return '';
    }
}

function convert(tag, o) {
    var doc = '<' + tag;

    if (typeof o === 'undefined' || o == null) {
        doc += '/>';
        return doc;
    }

    if (typeof o !== 'object') {
        doc += '>' + replaceXML(o) + '</' + tag + '>';
        return doc;
    }

    if (o.constructor == Object) {
        // Handle attributes (keys starting with @)
        for (var a in o) {
            if (a.charAt(0) == '@') {
                if (typeof o[a] !== 'object') {
                    doc += ' ' + a.substring(1) + '="' + o[a] + '"';
                    delete o[a];
                } else {
                    throw new Error((typeof o[a]) + ' being attribute is not supported.');
                }
            }
        }

        if (checkLength(o) === 0) {
            doc += '/>';
            return doc;
        } else {
            doc += '>';
        }

        // Handle #text nodes
        if (typeof o['#text'] !== 'undefined') {
            if (typeof o['#text'] !== 'object') {
                doc += o['#text'];
                delete o['#text'];
            } else {
                throw new Error((typeof o['#text']) + ' being #text is not supported.');
            }
        }

        // Process child elements
        for (var b in o) {
            if (o[b] !== null) {
                if (o[b].constructor == Array) {
                    for (var i = 0; i < o[b].length; i++) {
                        if (typeof o[b][i] !== 'object' || o[b][i].constructor == Object) {
                            doc += convert(b, o[b][i]);
                        } else {
                            throw new Error((typeof o[b][i]) + ' is not supported.');
                        }
                    }
                } else if (o[b].constructor == Object || typeof o[b] !== 'object') {
                    doc += convert(b, o[b]);
                } else {
                    throw new Error((typeof o[b]) + ' is not supported.');
                }
            } else {
                doc += convert(b, o[b]);
            }
        }

        doc += '</' + tag + '>';
        return doc;
    }
}

function replaceXML(value) {
    var s = value.toString();
    s = s.replace(/&/g, '&amp;');
    s = s.replace(/"/g, '&quot;');
    s = s.replace(/</g, '&lt;');
    s = s.replace(/>/g, '&gt;');
    return s;
}

function checkLength(o) {
    var n = 0;
    for (var a in o) {
        n++;
    }
    return n;
}

// Main execution - read JSON from the REQUEST body, convert to XML, set as response
var requestPayload = context.getVariable("request.content");

if (requestPayload) {
    // Parse the incoming JSON
    var jsonObj = JSON.parse(requestPayload);
    var attendeeSearchResponse = null;

    // Extract AttendeeSearchResponse from the nested data.attributes structure
    if (jsonObj.data && jsonObj.data.attributes && jsonObj.data.attributes.AttendeeSearchResponse) {
        attendeeSearchResponse = jsonObj.data.attributes.AttendeeSearchResponse;
    }

    if (attendeeSearchResponse) {
        // Wrap it as the root element for XML conversion
        var xmlInput = JSON.stringify({"AttendeeSearchResponse": attendeeSearchResponse});
        var xmlOutput = JSON2XML(xmlInput);
        context.setVariable("response.content", xmlOutput);
        context.setVariable("response.header.Content-Type", "application/xml");
    }
}
