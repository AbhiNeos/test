/**
 * ResolveErrorKey.js   —   cop_api_testing   (prefix: COP)
 *
 * Builds the KVM lookup key consumed by the SF-ErrorHandling shared flow.
 * No placeholder substitution is used for this API: every key maps to a complete
 * verbatim error body in the KVM.
 *
 * Outputs:
 *   custom.kvm.key      - COP_<apiproxy.name>_<SUFFIX>
 *   custom.kvm.status   - HTTP status returned to the consumer
 *   custom.kvm.resolved - always true (fallback keys always exist in the KVM)
 *
 * ---------------------------------------------------------------------------
 * RESOLUTION ORDER (first match wins)
 *
 *  1. BACKEND (fault.name = ErrorResponseCode)
 *       401,500,502,404,405,415,406,412 -> BE_<be>_500   (all return 500)
 *       anything else                   -> BE_500        (fallback, 500)
 *
 *  2. PLATFORM 403 (any)                -> _403                       403
 *
 *  3. PLATFORM 401 (any)                -> _401                       401
 *
 *  4. JOSE faults (fault.name driven)
 *       missing claim                   -> _400_JoseMissingClaim      400
 *       invalid claim                   -> _400_JoseInvalidClaim      400
 *       invalid value in header         -> _400_JoseInvalidHeader     400
 *       null value in header            -> _400_JoseNullHeader        400
 *       signature invalid after check   -> _400_JoseInvalidSignature  400
 *
 *  5. OAS VALIDATION  (all share one fault name, so we string-match the
 *     OAS fault cause; precedence matters - most specific first)
 *       Accept header invalid           -> _406_InvalidAccept         406
 *       unsupported media type          -> _415                       415
 *       method not allowed              -> _404                       404
 *       path not in spec                -> _500                       500
 *       x-fapi-financial-id missing     -> _400_MissingFapiId         400
 *       x-fapi-financial-id bad regex   -> _400_InvalidFapiId         400
 *       any other invalid header        -> _406_InvalidHeader         406
 *       field regex / invalid value     -> _400_InvalidFieldFormat    400
 *       payload / schema validation     -> _400_InvalidPayload        400
 *
 *  6. FALLBACK                          -> _500                       500
 * ---------------------------------------------------------------------------
 */

// ===========================================================================
// CONFIG
// ===========================================================================

var PREFIX = "COP";

// Backend status -> mapped (client-facing) status. Everything maps to 500 here.
// Any backend status NOT listed uses the fixed fallback key BE_500 (status 500).
var BACKEND_STATUS_MAP = {
    401: 500,
    404: 500,
    405: 500,
    406: 500,
    412: 500,
    415: 500,
    500: 500,
    502: 500
};

// The header this API treats as special for OAS header errors
var FAPI_HEADER = "x-fapi-financial-id";

// ===========================================================================
// Read Apigee error context
// ===========================================================================

var proxyName       = context.getVariable("apiproxy.name")     || "unknown";
var rawFaultName    = context.getVariable("fault.name")        || "";
var errorMessage    = context.getVariable("error.message")     || "";
var errorStatusCode = parseInt(context.getVariable("error.status.code") || "500", 10);

// OAS policy variables (policy is named OAS-Validate in this proxy)
var oasFaultCause = context.getVariable("OASValidation.OAS-Validate.fault.cause") || "";
var oasFailed     = context.getVariable("OASValidation.OAS-Validate.failed");

// ===========================================================================
// Helpers
// ===========================================================================

function setKey(suffix, status) {
    context.setVariable("custom.kvm.key", PREFIX + "_" + proxyName + "_" + suffix);
    context.setVariable("custom.kvm.status", String(status));
    context.setVariable("custom.kvm.resolved", true);
}

// RaiseFault hides the real policy name inside error.message
var faultName = rawFaultName;
if (rawFaultName === "RaiseFault" && errorMessage.indexOf("Fault name : ") !== -1) {
    faultName = errorMessage.split("Fault name : ")[1].trim();
}

// Text used for OAS string matching (fault cause preferred, message as fallback)
var oasText = (oasFaultCause || errorMessage);
var oasLower = oasText.toLowerCase();

// Case-insensitive substring test against the OAS text
function has(needle) {
    return oasLower.indexOf(String(needle).toLowerCase()) !== -1;
}

// True when ANY of the supplied substrings is present
function hasAny(list) {
    for (var i = 0; i < list.length; i++) {
        if (has(list[i])) { return true; }
    }
    return false;
}

var isOAS = (oasFailed === true || oasFailed === "true" || oasFaultCause !== "");

var handled = false;

// ===========================================================================
// 1. BACKEND ERRORS  (fault.name = "ErrorResponseCode")
// ===========================================================================

if (faultName === "ErrorResponseCode") {
    var backendStatus = errorStatusCode;
    if (BACKEND_STATUS_MAP.hasOwnProperty(backendStatus)) {
        setKey("BE_" + backendStatus + "_" + BACKEND_STATUS_MAP[backendStatus],
               BACKEND_STATUS_MAP[backendStatus]);
    } else {
        setKey("BE_500", 500);
    }
    handled = true;
}

// ===========================================================================
// 2. PLATFORM 403 -> single key
// ===========================================================================

if (!handled) {
    if (errorStatusCode === 403) {
        setKey("403", 403);
        handled = true;
    } else {
        switch (faultName) {
            case "InsufficientScope":
            case "ApiKeyNotApproved":
            case "app_not_approved":
            case "InvalidApiKeyForGivenResource":
            case "InvalidAPICallAsNoApiProductMatchFound":
            case "CompanyStatusNotActive":
            case "DeveloperStatusNotActive":
            case "IPDeniedAccess":
            case "RF-Forbidden":
                setKey("403", 403);
                handled = true;
                break;
            default:
                break;
        }
    }
}

// ===========================================================================
// 3. PLATFORM 401 -> single key
// ===========================================================================

if (!handled) {
    if (errorStatusCode === 401) {
        setKey("401", 401);
        handled = true;
    } else {
        switch (faultName) {
            case "FailedToResolveAccessToken":
            case "FailedToResolveToken":
            case "FailedToResolveAuthorizationCode":
            case "FailedToResolveAPIKey":
            case "InvalidAccessToken":
            case "invalid_access_token":
            case "access_token_expired":
            case "TokenExpired":
            case "InvalidApiKey":
            case "InvalidOperation":
            case "RF-Unauthorized":
                setKey("401", 401);
                handled = true;
                break;
            default:
                break;
        }
    }
}

// ===========================================================================
// 4. JOSE FAULTS -> distinct 400 keys (driven by fault.name)
//    Covers faults raised by JWS/JWT policies OR by custom JS/RaiseFault.
//    Add your real fault names to the relevant case as needed.
// ===========================================================================

if (!handled) {
    switch (faultName) {

        // (b) missing claim
        case "MissingClaim":
        case "FailedToResolveClaim":
        case "ClaimNotFound":
        case "RF-JoseMissingClaim":
            setKey("400_JoseMissingClaim", 400);
            handled = true;
            break;

        // (e) invalid claim
        case "InvalidClaim":
        case "ClaimValueMismatch":
        case "RF-JoseInvalidClaim":
            setKey("400_JoseInvalidClaim", 400);
            handled = true;
            break;

        // (c) invalid value in JOSE header
        case "BadJOSEHeader":
        case "InvalidJOSEHeader":
        case "AlgorithmMismatch":
        case "AlgorithmNotAllowed":
        case "RF-JoseInvalidHeader":
            setKey("400_JoseInvalidHeader", 400);
            handled = true;
            break;

        // (f) null value in JOSE header
        case "NullJOSEHeader":
        case "MissingJOSEHeader":
        case "RF-JoseNullHeader":
            setKey("400_JoseNullHeader", 400);
            handled = true;
            break;

        // (g) signature invalid after verification
        case "InvalidSignature":
        case "InvalidJWSSignature":
        case "JWSVerificationFailed":
        case "SignatureVerificationFailed":
        case "RF-JoseInvalidSignature":
            setKey("400_JoseInvalidSignature", 400);
            handled = true;
            break;

        default:
            break;
    }
}

// ===========================================================================
// 5. OAS VALIDATION
//    All OAS failures share one fault name, so the specific scenario is
//    identified by string-matching the OAS fault cause.
//    PRECEDENCE MATTERS - the structural/exceptional cases are checked first
//    because their messages can also contain generic words like "header".
// ===========================================================================

if (!handled && isOAS) {

    var fapiMentioned = has(FAPI_HEADER);

    // --- (ex-i) Accept header invalid -> 406 ---------------------------------
    // Checked BEFORE media-type because both mention content types.
    if (has("accept")) {
        setKey("406_InvalidAccept", 406);
        handled = true;
    }

    // --- (ex-iv) Unsupported media type -> 415 -------------------------------
    else if (hasAny([
        "unsupported media type",
        "media type",
        "content-type",
        "content type"
    ])) {
        setKey("415", 415);
        handled = true;
    }

    // --- (ex-v) Method not allowed -> 404 ------------------------------------
    else if (hasAny([
        "method not allowed",
        "not allowed for path",
        "request method",
        "operation not allowed"
    ])) {
        setKey("404", 404);
        handled = true;
    }

    // --- (ex-ii) Path not present in the spec -> default 500 -----------------
    else if (hasAny([
        "no api path found",
        "path not found",
        "no matching path"
    ])) {
        setKey("500", 500);
        handled = true;
    }

    // --- (2a) x-fapi-financial-id MISSING -> 400 ----------------------------
    else if (fapiMentioned && hasAny([
        "is required",
        "not found",
        "missing"
    ])) {
        setKey("400_MissingFapiId", 400);
        handled = true;
    }

    // --- (2d) x-fapi-financial-id INVALID REGEX -> 400 ----------------------
    else if (fapiMentioned && hasAny([
        "regex",
        "does not match",
        "pattern",
        "ecma 262"
    ])) {
        setKey("400_InvalidFapiId", 400);
        handled = true;
    }

    // --- (2d cont.) any other x-fapi-financial-id problem -> treat as invalid -
    else if (fapiMentioned) {
        setKey("400_InvalidFapiId", 400);
        handled = true;
    }

    // --- (ex-iii) Any OTHER invalid header -> 406 ---------------------------
    else if (hasAny([
        "header parameter",
        "header is required",
        "missing header",
        "invalid header",
        "header"
    ])) {
        setKey("406_InvalidHeader", 406);
        handled = true;
    }

    // --- (2h) Field-level regex / invalid value -> 400 ----------------------
    else if (hasAny([
        "regex",
        "does not match",
        "pattern",
        "ecma 262",
        "invalid value"
    ])) {
        setKey("400_InvalidFieldFormat", 400);
        handled = true;
    }

    // --- (2i) Payload / schema validation -> 400 ----------------------------
    else if (hasAny([
        "required properties",
        "instance type",
        "instance failed",
        "schema",
        "body",
        "payload",
        "object has missing",
        "is not a valid"
    ])) {
        setKey("400_InvalidPayload", 400);
        handled = true;
    }

    // Any other OAS failure falls through to the generic 500 fallback below.
    // (Change this to 400_InvalidPayload if you prefer a 400 catch-all for OAS.)
}

// ===========================================================================
// 6. DEFAULT FALLBACK -> 500
// ===========================================================================

if (!handled) {
    setKey("500", 500);
}
