<?xml version="1.0" encoding="UTF-8"?>
<!--
    ExtractAttendeeResponse.xsl
    Extracts the <AttendeeSearchResponse> element from the full JSONToXML output
    and makes it the root element of the response.

    Input (from JSONToXML):
    <root>
        <data>
            <id>GNE-046629</id>
            <type>attendees</type>
            <attributes>
                <AttendeeSearchResponse>
                    <Attendee>
                        <AttendeeTypeCode>GEPOC PreApproved</AttendeeTypeCode>
                        ...
                    </Attendee>
                </AttendeeSearchResponse>
            </attributes>
        </data>
    </root>

    Output:
    <AttendeeSearchResponse>
        <Attendee>
            <AttendeeTypeCode>GEPOC PreApproved</AttendeeTypeCode>
            ...
        </Attendee>
    </AttendeeSearchResponse>
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" indent="yes" encoding="UTF-8"/>

    <!-- Match the AttendeeSearchResponse node wherever it is in the tree -->
    <xsl:template match="/">
        <xsl:copy-of select="//AttendeeSearchResponse"/>
    </xsl:template>
</xsl:stylesheet>
