<?xml version="1.0" encoding="UTF-8"?>
<!--
    TransformAttendeeRequest.xsl
    Reshapes the incoming XML so that XMLToJSON produces the exact JSON structure needed.

    Input:
    <AttendeeSearchRequest>
        <Attendee>
            <AttendeeTypeCode>GEPOC</AttendeeTypeCode>
            <Custom8>GNE-054896</Custom8>
            ...
        </Attendee>
    </AttendeeSearchRequest>

    Output:
    <data>
        <type>findPreApprovals</type>
        <attributes>
            <AttendeeTypeCode>GEPOC</AttendeeTypeCode>
            <Custom8>GNE-054896</Custom8>
            ...
        </attributes>
    </data>

    When XMLToJSON converts this, it produces:
    {"data":{"type":"findPreApprovals","attributes":{"AttendeeTypeCode":"GEPOC","Custom8":"GNE-054896",...}}}
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" indent="no" omit-xml-declaration="yes"/>

    <xsl:template match="/">
        <data>
            <type>findPreApprovals</type>
            <attributes>
                <!-- Copy all children of Attendee as-is -->
                <xsl:for-each select="/AttendeeSearchRequest/Attendee/*">
                    <xsl:copy>
                        <xsl:value-of select="."/>
                    </xsl:copy>
                </xsl:for-each>
            </attributes>
        </data>
    </xsl:template>
</xsl:stylesheet>
