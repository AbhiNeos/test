/**
 * ApplyKvmSubstitution.js  (SF-ErrorHandling)
 *
 * Runs ONLY when custom.error.value is set (i.e. the resolved KVM entry contains
 * the placeholders "errorvalue1"/"errorvalue2" that need runtime substitution).
 *
 * Input variables:
 *   custom.kvm.errorBody  - JSON error body fetched from the KVM (contains placeholders)
 *   custom.error.value    - "errorvalue1-errorvalue2" (split on the FIRST dash;
 *                            v1 = before first dash, v2 = everything after; max two)
 *
 * Behaviour:
 *   - Replaces the literal token "errorvalue1" with v1 (all occurrences)
 *   - Replaces the literal token "errorvalue2" with v2 (all occurrences), if present
 *   - Writes the substituted body back to custom.kvm.errorBody
 *
 * Notes:
 *   - v1 must NOT contain a dash (v2 may). Split is on the first "-" only.
 *   - If only one value is supplied, only errorvalue1 is replaced.
 */

var body = context.getVariable("custom.kvm.errorBody") || "";
var combined = context.getVariable("custom.error.value") || "";

if (body !== "" && combined !== "") {

    var v1 = combined;
    var v2 = null;

    var dashIdx = combined.indexOf("-");
    if (dashIdx !== -1) {
        v1 = combined.substring(0, dashIdx);
        v2 = combined.substring(dashIdx + 1);
    }

    // Replace all occurrences of the placeholders (String.split/join = global replace)
    body = body.split("errorvalue1").join(v1);

    if (v2 !== null) {
        body = body.split("errorvalue2").join(v2);
    }

    context.setVariable("custom.kvm.errorBody", body);
}
