/**
 * ApplyKvmSubstitution.js  (SF-ErrorHandling)
 *
 * Runs ONLY when custom.error.value is set (i.e. the resolved KVM entry contains
 * the placeholder(s) "errorvalue1" and/or "errorvalue2" needing runtime substitution).
 *
 * Input variables:
 *   custom.kvm.errorBody  - JSON error body fetched from the KVM (contains placeholders)
 *   custom.error.value    - one of:
 *                             "v1"          -> single value  (replaces errorvalue1 only)
 *                             "v1||v2"      -> two values     (replaces errorvalue1 + errorvalue2)
 *                           Separator is "||" so real values may safely contain dashes.
 *
 * Behaviour (handles BOTH single- and two-value cases dynamically):
 *   - Always replaces "errorvalue1" with v1 (all occurrences)
 *   - Replaces "errorvalue2" with v2 (all occurrences) ONLY when a second value
 *     is present in custom.error.value
 *   - Writes the substituted body back to custom.kvm.errorBody
 */

var SEP = "||";

var body = context.getVariable("custom.kvm.errorBody") || "";
var combined = context.getVariable("custom.error.value") || "";

if (body !== "" && combined !== "") {

    var v1 = combined;
    var v2 = null;

    var sepIdx = combined.indexOf(SEP);
    if (sepIdx !== -1) {
        v1 = combined.substring(0, sepIdx);
        v2 = combined.substring(sepIdx + SEP.length);
    }

    // Single-value case: only errorvalue1 is replaced.
    body = body.split("errorvalue1").join(v1);

    // Two-value case: also replace errorvalue2.
    if (v2 !== null) {
        body = body.split("errorvalue2").join(v2);
    }

    context.setVariable("custom.kvm.errorBody", body);
}
