/**
 * EvaluateError.js
 *
 * Pure Apigee error evaluation script.
 * Detects errors from native Apigee fault variables and maps them to
 * a standardised JSON error response.
 *
 * Apigee Variables Used:
 *   fault.name                              - Policy-specific fault identifier
 *   error.status.code                       - HTTP status code of the error
 *   error.message                           - Error message string
 *   oasvalidation.{policy-name}.failure.reason - OAS Validation failure detail
 *
 * RAISEFAULT HANDLING:
 *   When a RaiseFault policy fires in any proxy:
 *     - fault.name = "RaiseFault" (always, regardless of policy name)
 *     - error.message = "Raising fault. Fault name : RF-PolicyName"
 *
 *   This script parses the actual policy name from error.message and uses THAT
 *   as the switch key, so each RF-* policy maps to its own error response.
 *
 *   To add a new RaiseFault error in any proxy:
 *     1. Create a RaiseFault policy named "RF-YourNewError" in the proxy
 *     2. Add a case "RF-YourNewError" in the RAISEFAULT section below
 *     3. No other wiring needed — the shared flow auto-detects it
 *
 * OAS Validation Policy:
 *   All OAS validation errors (invalid path, wrong method, unsupported media type,
 *   invalid request body, missing required fields, etc.) are mapped to 400 Bad Request.
 *
 * Error Response Shape:
 * {
 *   "Code":    "<status> <phrase>",
 *   "Id":      "APIGEE-<status>-001",
 *   "Message": "<high-level description>",
 *   "Errors": [
 *     {
 *       "ErrorCode": "<specific code>",
 *       "Message":   "<detailed message>",
 *       "Path":      "<field or resource path>",
 *       "Url":       "<documentation url>"
 *     }
 *   ]
 * }
 */

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------

function setFault(status, phrase, id, topMessage, errorCode, errorMessage, path, url) {
    var body = {
        "Code": status + " " + phrase,
        "Id": id,
        "Message": topMessage,
        "Errors": [
            {
                "ErrorCode": errorCode,
                "Message": errorMessage,
                "Path": path || "",
                "Url": url || ""
            }
        ]
    };
    context.setVariable("custom.error.status", String(status));
    context.setVariable("custom.error.phrase", phrase);
    context.setVariable("custom.error.code", errorCode);
    context.setVariable("custom.error.body", JSON.stringify(body, null, 4));
}

// ---------------------------------------------------------------------------
// Read Apigee error context variables
// ---------------------------------------------------------------------------

var rawFaultName = context.getVariable("fault.name") || "";
var errorStatusCode = parseInt(context.getVariable("error.status.code") || "500", 10);
var errorMessage = context.getVariable("error.message") || "";

// OAS Validation failure reason (available when OASValidation policy triggers fault)
var oasFailureReason = context.getVariable("oasvalidation.OAS-Validate.failure.reason") ||
                       context.getVariable("oasvalidation.OAS-RequestValidation.failure.reason") ||
                       context.getVariable("oasvalidation.OASValidation.failure.reason") ||
                       "";

// ---------------------------------------------------------------------------
// RESOLVE FAULT NAME
//
// For most policies, fault.name = the specific fault (e.g. "InvalidAccessToken")
// For RaiseFault policies, fault.name = "RaiseFault" ALWAYS.
// To identify WHICH RaiseFault fired, parse error.message:
//   "Raising fault. Fault name : RF-CustomError"
// ---------------------------------------------------------------------------
var faultName = "";

if (rawFaultName === "RaiseFault" && errorMessage.indexOf("Fault name : ") !== -1) {
    // Extract the policy name after "Fault name : "
    var parts = errorMessage.split("Fault name : ");
    if (parts.length > 1) {
        faultName = parts[1].trim();
    }
} else {
    faultName = rawFaultName;
}

// ---------------------------------------------------------------------------
// Map fault to error response
// ---------------------------------------------------------------------------

switch (faultName) {

    // =======================================================================
    // RAISEFAULT POLICIES (parsed from error.message)
    // Proxies can define their own RF-* policies and add cases here.
    // Each RF-* maps to a specific custom error response.
    //
    // HOW TO ADD A NEW RAISEFAULT ERROR:
    //   1. In your proxy, create a RaiseFault policy named "RF-YourNewError"
    //   2. Add a case below:
    //      case "RF-YourNewError":
    //          setFault(status, phrase, id, message, code, detail, path, url);
    //          break;
    //   3. The shared flow will auto-detect it via error.message parsing
    // =======================================================================

    // --- Proxy-specific: Invalid credentials (e.g. Basic Auth) ---
    // case "RF-InvalidCredentials":
    //     setFault(
    //         401, "Unauthorized",
    //         "APIGEE-401-002",
    //         "Authentication credentials are missing or invalid",
    //         "INVALID_CREDENTIALS",
    //         "The provided client_id or client_secret does not match a registered application",
    //         "/headers/Authorization",
    //         "https://developer.barclays.com/errors/authentication"
    //     );
    //     break;

    // // --- Proxy-specific: Custom business validation failure ---
    // case "RF-BusinessValidationError":
    //     var customMsg = context.getVariable("custom.error.detail") || "Business rule validation failed";
    //     setFault(
    //         400, "Bad Request",
    //         "APIGEE-400-002",
    //         "Business validation failed",
    //         "BUSINESS_RULE_VIOLATION",
    //         customMsg,
    //         "/request/body",
    //         "https://developer.barclays.com/errors/business-validation"
    //     );
    //     break;

    // // --- Proxy-specific: Resource forbidden (scope/role check) ---
    // case "RF-Forbidden":
    //     setFault(
    //         403, "Forbidden",
    //         "APIGEE-403-002",
    //         "Access to this resource is forbidden",
    //         "ACCESS_DENIED",
    //         "You do not have the required role or scope to access this resource",
    //         "/api/resource",
    //         "https://developer.barclays.com/errors/authorization"
    //     );
    //     break;

    // // --- Proxy-specific: Custom not found ---
    // case "RF-ResourceNotFound":
    //     setFault(
    //         404, "Not Found",
    //         "APIGEE-404-001",
    //         "Requested resource not found",
    //         "RESOURCE_NOT_FOUND",
    //         "No resource found for the given identifier",
    //         "/api/resource/{id}",
    //         "https://developer.barclays.com/errors/not-found"
    //     );
    //     break;

    // // --- Proxy-specific: Custom conflict ---
    // case "RF-Conflict":
    //     setFault(
    //         409, "Conflict",
    //         "APIGEE-409-001",
    //         "Request conflicts with current state",
    //         "RESOURCE_CONFLICT",
    //         "The request could not be completed due to a conflict with the current state of the resource",
    //         "/api/resource",
    //         "https://developer.barclays.com/errors/conflict"
    //     );
    //     break;

    // // --- Proxy-specific: Downstream service error ---
    // case "RF-ServiceUnavailable":
    //     setFault(
    //         503, "Service Unavailable",
    //         "APIGEE-503-002",
    //         "Dependent service is unavailable",
    //         "DEPENDENT_SERVICE_DOWN",
    //         "A required downstream service is temporarily unavailable",
    //         "/target/endpoint",
    //         "https://developer.barclays.com/errors/service-unavailable"
    //     );
    //     break;

    // ─── Add your new RaiseFault cases below this line ─────────────────────
    //
    // case "RF-YourNewError":
    //     setFault(
    //         <status>, "<phrase>",
    //         "<id>",
    //         "<top-level message>",
    //         "<error code>",
    //         "<detailed message>",
    //         "<path>",
    //         "<url>"
    //     );
    //     break;
    //
    // ───────────────────────────────────────────────────────────────────────

    // =======================================================================
    // OAS VALIDATION ERRORS → ALL 400 Bad Request
    // Covers: invalid path, wrong method, unsupported media type,
    //         invalid request body, missing required parameters, schema violations
    // =======================================================================
    case "OASValidationFailure":
    case "OASValidation":
    case "OASViolation":
    case "PathBasedValidationFailure":
        var oasDetail = oasFailureReason || errorMessage || "Request failed OAS validation";
        setFault(
            400, "Bad Request",
            "APIGEE-400-001",
            "Invalid request payload or parameters",
            "INVALID_INPUT",
            oasDetail,
            "/request",
            "https://developer.barclays.com/errors/invalid-input"
        );
        break;

    // =======================================================================
    // Case 1: Invalid Request (400 Bad Request)
    // Triggered by: JSONThreatProtection, XMLThreatProtection, validation faults
    // =======================================================================
    case "ExceededContainerDepth":
    case "ExceededObjectEntryCount":
    case "ExceededArrayElementCount":
    case "ExceededObjectEntryNameLength":
    case "ExceededStringValueLength":
    case "ThreatDetected":
    case "SourceUnavailable":
    case "NonMessageVariable":
    case "ExecutionFailed":
    case "InvalidJsonFormat":
        setFault(
            400, "Bad Request",
            "APIGEE-400-001",
            "Invalid request payload or parameters",
            "INVALID_INPUT",
            "Request body contains invalid or missing fields",
            "/request/body",
            "https://developer.barclays.com/errors/invalid-input"
        );
        break;

    // =======================================================================
    // Case 2: Unauthorized (401 Unauthorized)
    // Triggered by: OAuthV2, VerifyAPIKey, JWT validation failures
    // =======================================================================
    case "FailedToResolveAccessToken":
    case "FailedToResolveToken":
    case "FailedToResolveAuthorizationCode":
    case "InvalidAccessToken":
    case "access_token_expired":
    case "invalid_access_token":
    case "TokenExpired":
    case "InvalidJWT":
    case "BadJOSEHeader":
    case "AlgorithmNotAllowed":
    case "InvalidClaim":
    case "FailedToResolveClaim":
    case "InvalidApiKey":
    case "FailedToResolveAPIKey":
    case "DecryptionFailed":
    case "JWEDecryptionFailed":
        setFault(
            401, "Unauthorized",
            "APIGEE-401-001",
            "Authentication Failed",
            "INVALID_TOKEN",
            "Access token is missing or invalid",
            "/headers/Authorization",
            "https://developer.barclays.com/errors/authentication"
        );
        break;

    // =======================================================================
    // Case 3a: Forbidden (403 Forbidden)
    // Triggered by: Scope check failures, API product mismatch
    // =======================================================================
    case "InsufficientScope":
    case "InvalidApiKeyForGivenResource":
    case "InvalidAPICallAsNoApiProductMatchFound":
    case "ApiKeyNotApproved":
    case "app_not_approved":
    case "CompanyStatusNotActive":
    case "DeveloperStatusNotActive":
        setFault(
            403, "Forbidden",
            "APIGEE-403-001",
            "Access denied",
            "INSUFFICIENT_SCOPE",
            "Client does not have required permissions",
            "/api/resource",
            "https://developer.barclays.com/errors/authorization"
        );
        break;

    // =======================================================================
    // Case 5: Request Timeout (408 Request Timeout)
    // Triggered by: Target connection timeout, io.timeout.millis exceeded
    // =======================================================================
    case "GatewayTimeout":
    case "ClientTimeout":
    case "Timeout":
    case "ConnectionTimeout":
        setFault(
            408, "Request Timeout",
            "APIGEE-408-001",
            "Request timeout",
            "CLIENT_TIMEOUT",
            "Client failed to send request within allowed time",
            "/api/resource",
            "https://developer.barclays.com/errors/timeout"
        );
        break;

    // =======================================================================
    // Case 7: Rate Limit Exceeded (429 Too Many Requests)
    // Triggered by: SpikeArrest, Quota policy violations
    // =======================================================================
    case "SpikeArrestViolation":
    case "QuotaViolation":
    case "InvalidMessageWeight":
    case "FailedToResolveSpikeArrestRate":
    case "InvalidQuotaInterval":
    case "InvalidQuotaTimeUnit":
    case "FailedToResolveQuotaIntervalReference":
        setFault(
            429, "Too Many Requests",
            "APIGEE-429-001",
            "Rate limit exceeded",
            "QUOTA_EXCEEDED",
            "API rate limit has been exceeded",
            "/api/resource",
            "https://developer.barclays.com/errors/rate-limit"
        );
        break;

    // =======================================================================
    // Case 9: Bad Gateway (502 Bad Gateway)
    // Triggered by: Target returns invalid/malformed response
    // =======================================================================
    case "BadGateway":
    case "JWKSFetchFailed":
    case "JWKSResponseUnexpected":
        setFault(
            502, "Bad Gateway",
            "APIGEE-502-001",
            "Invalid response from downstream service",
            "DOWNSTREAM_ERROR",
            "Received invalid response from backend service",
            "/target/endpoint",
            "https://developer.barclays.com/errors/bad-gateway"
        );
        break;

    // =======================================================================
    // Case 10: Service Unavailable (503 Service Unavailable)
    // Triggered by: Target unreachable, connection refused, SSL error
    // =======================================================================
    case "ServiceUnavailable":
    case "TargetConnectFailed":
    case "ConnectionRefused":
    case "SSLHandshakeFailed":
    case "SSLInfoAccessFailure":
        setFault(
            503, "Service Unavailable",
            "APIGEE-503-001",
            "Service temporarily unavailable",
            "SERVICE_DOWN",
            "Backend service is currently unavailable",
            "/target/endpoint",
            "https://developer.barclays.com/errors/service-unavailable"
        );
        break;

    // =======================================================================
    // ErrorResponseCode - backend returned an error status
    // =======================================================================
    case "ErrorResponseCode":
        var backendStatus = parseInt(context.getVariable("error.status.code"), 10) || 502;
        if (backendStatus >= 500) {
            setFault(
                503, "Service Unavailable",
                "APIGEE-503-001",
                "Service temporarily unavailable",
                "SERVICE_DOWN",
                "Backend service is currently unavailable",
                "/target/endpoint",
                "https://developer.barclays.com/errors/service-unavailable"
            );
        } else {
            setFault(
                502, "Bad Gateway",
                "APIGEE-502-001",
                "Invalid response from downstream service",
                "DOWNSTREAM_ERROR",
                "Received invalid response from backend service",
                "/target/endpoint",
                "https://developer.barclays.com/errors/bad-gateway"
            );
        }
        break;

    // =======================================================================
    // Default: fallback detection
    // =======================================================================
    default:
        // Check if custom.error.case was explicitly set by the proxy
        var explicitCase = context.getVariable("custom.error.case") || "";

        if (explicitCase) {
            switch (explicitCase) {
                case "INVALID_REQUEST":
                    setFault(400, "Bad Request", "APIGEE-400-001", "Invalid request payload or parameters", "INVALID_INPUT", "Request body contains invalid or missing fields", "/request/body", "https://developer.barclays.com/errors/invalid-input");
                    break;
                case "UNAUTHORIZED":
                    setFault(401, "Unauthorized", "APIGEE-401-001", "Authentication Failed", "INVALID_TOKEN", "Access token is missing or invalid", "/headers/Authorization", "https://developer.barclays.com/errors/authentication");
                    break;
                case "FORBIDDEN":
                    setFault(403, "Forbidden", "APIGEE-403-001", "Access denied", "INSUFFICIENT_SCOPE", "Client does not have required permissions", "/api/resource", "https://developer.barclays.com/errors/authorization");
                    break;
                case "NOT_FOUND":
                    setFault(400, "Bad Request", "APIGEE-400-001", "Invalid request payload or parameters", "OAS_VALIDATION_FAILURE", "Requested path does not exist in the API specification", "/request/path", "https://developer.barclays.com/errors/invalid-input");
                    break;
                case "METHOD_NOT_ALLOWED":
                    setFault(400, "Bad Request", "APIGEE-400-001", "Invalid request payload or parameters", "OAS_VALIDATION_FAILURE", "The HTTP method used is not defined in the API specification for this path", "/request/method", "https://developer.barclays.com/errors/invalid-input");
                    break;
                case "REQUEST_TIMEOUT":
                    setFault(408, "Request Timeout", "APIGEE-408-001", "Request timeout", "CLIENT_TIMEOUT", "Client failed to send request within allowed time", "/api/resource", "https://developer.barclays.com/errors/timeout");
                    break;
                case "UNSUPPORTED_MEDIA_TYPE":
                    setFault(400, "Bad Request", "APIGEE-400-001", "Invalid request payload or parameters", "OAS_VALIDATION_FAILURE", "Content-Type header is not defined in the API specification", "/headers/Content-Type", "https://developer.barclays.com/errors/invalid-input");
                    break;
                case "RATE_LIMIT_EXCEEDED":
                    setFault(429, "Too Many Requests", "APIGEE-429-001", "Rate limit exceeded", "QUOTA_EXCEEDED", "API rate limit has been exceeded", "/api/resource", "https://developer.barclays.com/errors/rate-limit");
                    break;
                case "INTERNAL_ERROR":
                    setFault(500, "Internal Server Error", "APIGEE-500-001", "Unexpected server error", "INTERNAL_ERROR", "An unknown error occurred at gateway", "/apigee/gateway", "https://developer.barclays.com/errors/internal");
                    break;
                case "BAD_GATEWAY":
                    setFault(502, "Bad Gateway", "APIGEE-502-001", "Invalid response from downstream service", "DOWNSTREAM_ERROR", "Received invalid response from backend service", "/target/endpoint", "https://developer.barclays.com/errors/bad-gateway");
                    break;
                case "SERVICE_DOWN":
                    setFault(503, "Service Unavailable", "APIGEE-503-001", "Service temporarily unavailable", "SERVICE_DOWN", "Backend service is currently unavailable", "/target/endpoint", "https://developer.barclays.com/errors/service-unavailable");
                    break;
                default:
                    setFault(500, "Internal Server Error", "APIGEE-500-001", "Unexpected server error", "INTERNAL_ERROR", "An unknown error occurred at gateway", "/apigee/gateway", "https://developer.barclays.com/errors/internal");
                    break;
            }
        } else {
            // Last resort: map by error.status.code
            switch (errorStatusCode) {
                case 400:
                    setFault(400, "Bad Request", "APIGEE-400-001", "Invalid request payload or parameters", "INVALID_INPUT", "Request body contains invalid or missing fields", "/request/body", "https://developer.barclays.com/errors/invalid-input");
                    break;
                case 401:
                    setFault(401, "Unauthorized", "APIGEE-401-001", "Authentication Failed", "INVALID_TOKEN", "Access token is missing or invalid", "/headers/Authorization", "https://developer.barclays.com/errors/authentication");
                    break;
                case 403:
                    setFault(403, "Forbidden", "APIGEE-403-001", "Access denied", "INSUFFICIENT_SCOPE", "Client does not have required permissions", "/api/resource", "https://developer.barclays.com/errors/authorization");
                    break;
                case 404:
                    // OAS handles path validation — 404 from OAS = 400
                    setFault(400, "Bad Request", "APIGEE-400-001", "Invalid request payload or parameters", "OAS_VALIDATION_FAILURE", "Requested path does not exist in the API specification", "/request/path", "https://developer.barclays.com/errors/invalid-input");
                    break;
                case 405:
                    // OAS handles method validation — 405 from OAS = 400
                    setFault(400, "Bad Request", "APIGEE-400-001", "Invalid request payload or parameters", "OAS_VALIDATION_FAILURE", "The HTTP method used is not defined in the API specification for this path", "/request/method", "https://developer.barclays.com/errors/invalid-input");
                    break;
                case 408:
                    setFault(408, "Request Timeout", "APIGEE-408-001", "Request timeout", "CLIENT_TIMEOUT", "Client failed to send request within allowed time", "/api/resource", "https://developer.barclays.com/errors/timeout");
                    break;
                case 415:
                    // OAS handles media type validation — 415 from OAS = 400
                    setFault(400, "Bad Request", "APIGEE-400-001", "Invalid request payload or parameters", "OAS_VALIDATION_FAILURE", "Content-Type header is not defined in the API specification", "/headers/Content-Type", "https://developer.barclays.com/errors/invalid-input");
                    break;
                case 429:
                    setFault(429, "Too Many Requests", "APIGEE-429-001", "Rate limit exceeded", "QUOTA_EXCEEDED", "API rate limit has been exceeded", "/api/resource", "https://developer.barclays.com/errors/rate-limit");
                    break;
                case 502:
                    setFault(502, "Bad Gateway", "APIGEE-502-001", "Invalid response from downstream service", "DOWNSTREAM_ERROR", "Received invalid response from backend service", "/target/endpoint", "https://developer.barclays.com/errors/bad-gateway");
                    break;
                case 503:
                    setFault(503, "Service Unavailable", "APIGEE-503-001", "Service temporarily unavailable", "SERVICE_DOWN", "Backend service is currently unavailable", "/target/endpoint", "https://developer.barclays.com/errors/service-unavailable");
                    break;
                default:
                    setFault(500, "Internal Server Error", "APIGEE-500-001", "Unexpected server error", "INTERNAL_ERROR", "An unknown error occurred at gateway", "/apigee/gateway", "https://developer.barclays.com/errors/internal");
                    break;
            }
        }
        break;
}
