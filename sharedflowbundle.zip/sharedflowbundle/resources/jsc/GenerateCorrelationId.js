/**
 * GenerateCorrelationId.js
 *
 * Generates a UUID v4 compliant correlation ID (RFC 4122) and sets it
 * as both the Correlation-ID and x-fapi-interaction-id request headers.
 *
 * This script only runs when NEITHER header is present (condition on policy step).
 *
 * UUID v4 format: xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
 *   where y is one of [8, 9, a, b]
 *
 * Pattern: ^[A-Za-f0-9]{8}-?[A-Za-f0-9]{4}-?[1-5][A-Za-f0-9]{3}-?[89ab][A-Za-f0-9]{3}-?[A-Za-f0-9]{12}$
 */

function generateUUIDv4() {
    var hex = '0123456789abcdef';
    var uuid = '';
    for (var i = 0; i < 36; i++) {
        if (i === 8 || i === 13 || i === 18 || i === 23) {
            uuid += '-';
        } else if (i === 14) {
            uuid += '4'; // version 4
        } else if (i === 19) {
            uuid += hex.charAt(Math.floor(Math.random() * 4) + 8); // variant [8,9,a,b]
        } else {
            uuid += hex.charAt(Math.floor(Math.random() * 16));
        }
    }
    return uuid;
}

var correlationId = generateUUIDv4();

// Set as request headers so downstream policies and target can use them
context.setVariable("request.header.Correlation-ID", correlationId);
