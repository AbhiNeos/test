// =====================================================
// 1. Re-evaluated Flow Check (Shared Flow Friendly Guard Rails)
// =====================================================
var nativeFlow = context.flow; // Will be "SHARED_FLOW" if called via Callout
var sharedFlowState = String(context.getVariable('currentstep.flowstate') || '');
var isErrorFlow = context.getVariable('flow.error') === true || context.getVariable('error') !== null;

// Allow execution if either the proxy natively hits PROXY_RESP_FLOW, 
// the shared flow context tells us it's the final stage, or an error happens.
if (nativeFlow === 'PROXY_RESP_FLOW' || sharedFlowState === 'PROXY_RESP_FLOW' || sharedFlowState === 'RESP_SENT' || isErrorFlow) {
    // --- Helper: Safe variable read with Java-to-JS type conversion ---
    function getVar(name) {
        try {
            var val = context.getVariable(name);
            if (val === null || typeof val === 'undefined') {
                return null;
            }
            
            var className = val.getClass ? String(val.getClass().getName()) : '';
            if (className === 'java.lang.String') return String(val);
            if (className === 'java.lang.Boolean') return val.booleanValue() === true;
            if (className === 'java.lang.Integer' || 
                className === 'java.lang.Long' || 
                className === 'java.lang.Double' || 
                className === 'java.lang.Float') {
                return Number(val);
            }
            return String(val);
        } catch (e) {
            try { return String(val); } catch (err) { return null; }
        }
    }

    // --- Helper: Safe JSON parse ---
    function parseLogpoint(varName) {
        var raw = getVar(varName);
        if (!raw) return null;
        try {
            return JSON.parse(raw);
        } catch (e) {
            return { parse_error: String(e.message), raw_data: String(raw).substring(0, 500) };
        }
    }

    // --- Helper: Remove null/undefined values from object ---
    function cleanObject(obj) {
        if (!obj || typeof obj !== 'object') return obj;
        var cleaned = {};
        for (var key in obj) {
            if (obj.hasOwnProperty(key) && obj[key] !== null && typeof obj[key] !== 'undefined') {
                cleaned[key] = obj[key];
            }
        }
        return cleaned;
    }

    // =====================================================
    // Collect all logpoints dynamically
    // =====================================================
    var logpoints = [];
    var logpointNames = [
        'REQUEST_RECEIVED',
        'REQUEST_TO_TARGET',
        'RESPONSE_FROM_TARGET',
        'RESPONSE_TO_CLIENT'
    ];

    var capturedCount = 0;
    for (var i = 0; i < logpointNames.length; i++) {
        var lp = parseLogpoint('logging.data.' + logpointNames[i]);
        if (lp) {
            logpoints.push(cleanObject(lp));
            capturedCount++;
        }
    }

    // Check for error logpoint
    var errorLogpoint = parseLogpoint('logging.data.ERROR');
    if (errorLogpoint) {
        logpoints.push(cleanObject(errorLogpoint));
    }

    // =====================================================
    // Determine overall log level
    // =====================================================
    var isError = isErrorFlow || (getVar('is_error') + '') === 'true';

    // =====================================================
    // Compute timing metrics (with safety fallbacks for failures)
    // =====================================================
    var clientReceivedStart = getVar('client.received.start.timestamp');
    var clientSentEnd = getVar('client.sent.end.timestamp');
    var targetSentStart = getVar('target.sent.start.timestamp');
    var targetSentEnd = getVar('target.sent.end.timestamp');
    var targetReceivedStart = getVar('target.received.start.timestamp');
    var targetReceivedEnd = getVar('target.received.end.timestamp');

    var metrics = {};

    // Total request time (client received to client sent)
    if (clientReceivedStart && clientSentEnd) {
        metrics.total_time_ms = parseInt(clientSentEnd, 10) - parseInt(clientReceivedStart, 10);
    }

    // Target response time (target sent to target received)
    if (targetSentStart && targetReceivedEnd) {
        metrics.target_time_ms = parseInt(targetReceivedEnd, 10) - parseInt(targetSentStart, 10);
    }

    // Target connection time
    if (targetSentStart && targetSentEnd) {
        metrics.target_connect_time_ms = parseInt(targetSentEnd, 10) - parseInt(targetSentStart, 10);
    }

    // Target backend processing time
    if (targetSentEnd && targetReceivedStart) {
        metrics.target_processing_time_ms = parseInt(targetReceivedStart, 10) - parseInt(targetSentEnd, 10);
    }

    // Proxy processing time (total minus target)
    if (metrics.total_time_ms && metrics.target_time_ms) {
        metrics.proxy_processing_ms = metrics.total_time_ms - metrics.target_time_ms;
    }

    // =====================================================
    // Security context
    // =====================================================
    var securityContext = cleanObject({
        api_product: getVar('apiproduct.name'),
        developer_app: getVar('developer.app.name'),
        developer_email: getVar('developer.email'),
        client_id: getVar('client_id'),
        access_token: getVar('access_token') ? '***' : null,
        scope: getVar('scope'),
        grant_type: getVar('grant_type')
    });

    // =====================================================
    // Error details (only on fault)
    // =====================================================
    var errorDetails = null;
    if (isError) {
        errorDetails = cleanObject({
            fault_name: getVar('fault.name'),
            fault_type: getVar('fault.type'),
            fault_category: getVar('fault.category'),
            fault_subcategory: getVar('fault.subcategory'),
            fault_reason: getVar('fault.reason'),
            error_message: getVar('error.message'),
            error_status_code: getVar('error.status.code'),
            error_reason_phrase: getVar('error.reason.phrase'),
            error_transport_message: getVar('error.transport.message'),
            error_state: getVar('error.state'),
            error_content: (function() {
                var ec = getVar('error.content');
                if (ec) {
                    var s = String(ec);
                    return s.length > 2048 ? s.substring(0, 2048) + '...[truncated]' : s;
                }
                return null;
            })()
        });
    }

    // =====================================================
    // Build final log object
    // =====================================================
var finalLog = {
        transaction_id: getVar('messageid'),
        timestamp: new Date().toISOString(),
        log_level: isError ? 'ERROR' : 'INFO',
        organization: getVar('organization.name'),
        environment: getVar('environment.name'),
        api_proxy: getVar('apiproxy.name'),
        proxy_revision: getVar('apiproxy.revision'),
        virtual_host: getVar('virtualhost.name'),
        logpoints_captured: capturedCount,
        logpoints_expected: 4,
        is_complete: capturedCount === 4 && !isError,
        logpoints: logpoints,
        metrics: cleanObject(metrics),
        security_context: securityContext,
        apigee_flow_context: (sharedFlowState !== '') ? sharedFlowState : nativeFlow // Corrects the metadata output
    };

    if (errorDetails) {
        finalLog.error_details = errorDetails;
    }

    // Add final response status summary (safely using 'message' fallback if error)
    finalLog.summary = cleanObject({
        http_method: getVar('request.verb'),
        request_uri: getVar('request.uri'),
        response_status_code: isError ? (getVar('error.status.code') || getVar('message.status.code')) : getVar('response.status.code'),
        client_ip: getVar('client.ip'),
        target_url: getVar('target.url')
    });

    // =====================================================
    // Store the final payload
    // =====================================================
    context.setVariable('logging.final_payload', JSON.stringify(finalLog));
}