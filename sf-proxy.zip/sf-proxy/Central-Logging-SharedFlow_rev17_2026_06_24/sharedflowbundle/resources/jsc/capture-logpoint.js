// 1. --- DYNAMIC FLOW DETECTION VIA APIGEE FLOWSTATE (SHARED FLOW FRIENDLY) ---
// Inside Shared Flows, context.flow returns "SHARED_FLOW". 
// currentstep.flowstate tracks the actual underlying proxy execution context.
var nativeFlow = String(context.getVariable('currentstep.flowstate') || '');
var isErrorFlow = context.getVariable('flow.error') === true || context.getVariable('error') !== null;
var logpoint = 'UNKNOWN';

if (isErrorFlow) {
    logpoint = 'ERROR';
} else {
    // Map the real execution context strings to your logpoint names
    switch (nativeFlow) {
        case 'PROXY_REQ_FLOW':
            logpoint = 'REQUEST_RECEIVED';
            break;
        case 'TARGET_REQ_FLOW':
            logpoint = 'REQUEST_TO_TARGET';
            break;
        case 'TARGET_RESP_FLOW':
            logpoint = 'RESPONSE_FROM_TARGET';
            break;
        case 'PROXY_RESP_FLOW':
        case 'RESP_SENT': // Catches cases where Shared Flow is attached to a PostProxy/PostClient Flow Hook
            logpoint = 'RESPONSE_TO_CLIENT';
            break;
        default:
            logpoint = 'UNKNOWN';
            break;
    }
}

var capturePayload = (String(context.getVariable('logging.capture_payload') || 'false')) === 'true';
var MAX_PAYLOAD_SIZE = 10240; // 10KB max payload capture

// --- Helper: Safe variable read with Java-to-JS type conversion ---
function getVar(name) {
    try {
        var val = context.getVariable(name);
        if (val === null || typeof val === 'undefined') {
            return null;
        }
        
        var className = val.getClass ? String(val.getClass().getName()) : '';
        if (className === 'java.lang.String') return String(val);
        if (className === 'java.lang.Boolean') return val.booleanValue() === true;
        if (className === 'java.lang.Integer' || 
            className === 'java.lang.Long' || 
            className === 'java.lang.Double' || 
            className === 'java.lang.Float') {
            return Number(val);
        }
        return String(val);
    } catch (e) {
        try { return String(val); } catch (err) { return null; }
    }
}

// --- Helper: Get all headers as an object ---
function getHeaders(prefix) {
    var headers = {};
    var headerNames = context.getVariable(prefix + '.headers.names');
    if (!headerNames) return headers;

    var headerNamesStr = String(headerNames).replace(/^\[/, '').replace(/\]$/, '');
    var names = headerNamesStr.split(', ');
    for (var i = 0; i < names.length; i++) {
        var name = names[i].trim();
        if (name === '') continue;
        var value = context.getVariable(prefix + '.header.' + name);
        if (value !== null && typeof value !== 'undefined') {
            var valueStr = String(value);
            if (name.toLowerCase() === 'authorization') {
                valueStr = valueStr.length > 10 ? 
                    valueStr.substring(0, valueStr.indexOf(' ') + 1) + '***' + valueStr.substring(valueStr.length - 4) : '***';
            }
            headers[name] = valueStr;
        }
    }
    return headers;
}

// --- Helper: Get payload with size limit ---
function getPayload(prefix) {
    if (!capturePayload) return undefined;
    var content = getVar(prefix + '.content');
    if (!content) return null;
    var str = String(content);
    if (str.length > MAX_PAYLOAD_SIZE) {
        return {
            content: str.substring(0, MAX_PAYLOAD_SIZE),
            truncated: true,
            original_size: str.length
        };
    }
    return { content: str, truncated: false, original_size: str.length };
}

// --- Helper: Get content length ---
function getContentLength(prefix) {
    var len = getVar(prefix + '.header.Content-Length');
    if (len) return parseInt(String(len), 10);
    var content = getVar(prefix + '.content');
    if (content) return String(content).length;
    return 0;
}

// --- Build the logpoint data object ---
var data = {
    name: logpoint,
    apigee_flow_context: nativeFlow, // Captures PROXY_REQ_FLOW, TARGET_RESP_FLOW, etc.
    timestamp: new Date().toISOString()
};

// =====================================================
// LOGPOINT 1: REQUEST_RECEIVED (PROXY_REQ_FLOW)
// =====================================================
if (logpoint === 'REQUEST_RECEIVED') {
    data.client_ip = getVar('client.ip');
    data.client_port = getVar('client.port');
    data.proxy_client_ip = getVar('proxy.client.ip');
    data.client_scheme = getVar('client.scheme');
    data.client_cn = getVar('client.cn');

    data.http_method = getVar('request.verb');
    data.request_uri = getVar('request.uri');
    data.request_path = getVar('request.path');
    data.query_string = getVar('request.querystring');
    data.proxy_url = getVar('proxy.url');
    data.proxy_basepath = getVar('proxy.basepath');
    data.proxy_pathsuffix = getVar('proxy.pathsuffix');

    data.headers = getHeaders('request');
    data.payload_size = getContentLength('request');
    var payload = getPayload('request');
    if (payload !== undefined) data.payload = payload;

    data.client_received_start_timestamp = getVar('client.received.start.timestamp');
    data.client_received_end_timestamp = getVar('client.received.end.timestamp');
}

// =====================================================
// LOGPOINT 2: REQUEST_TO_TARGET (TARGET_REQ_FLOW)
// =====================================================
else if (logpoint === 'REQUEST_TO_TARGET') {
    data.target_url = getVar('target.url');
    data.target_name = getVar('target.name');
    data.target_basepath = getVar('target.basepath');
    data.target_copy_pathsuffix = getVar('target.copy.pathsuffix');
    data.targetserver_name = getVar('targetserver.name');

    data.http_method = getVar('request.verb');
    data.request_uri = getVar('request.uri');
    data.request_path = getVar('request.path');
    data.query_string = getVar('request.querystring');

    data.headers = getHeaders('request');
    data.payload_size = getContentLength('request');
    var payload2 = getPayload('request');
    if (payload2 !== undefined) data.payload = payload2;

    data.target_sent_start_timestamp = getVar('target.sent.start.timestamp');
}

// =====================================================
// LOGPOINT 3: RESPONSE_FROM_TARGET (TARGET_RESP_FLOW)
// =====================================================
else if (logpoint === 'RESPONSE_FROM_TARGET') {
    data.status_code = getVar('response.status.code');
    data.reason_phrase = getVar('response.reason.phrase');

    data.target_url = getVar('target.url');
    data.target_name = getVar('target.name');

    data.headers = getHeaders('response');
    data.payload_size = getContentLength('response');
    var payload3 = getPayload('response');
    if (payload3 !== undefined) data.payload = payload3;

    data.target_sent_start_timestamp = getVar('target.sent.start.timestamp');
    data.target_sent_end_timestamp = getVar('target.sent.end.timestamp');
    data.target_received_start_timestamp = getVar('target.received.start.timestamp');
    data.target_received_end_timestamp = getVar('target.received.end.timestamp');
}

// =====================================================
// LOGPOINT 4: RESPONSE_TO_CLIENT (PROXY_RESP_FLOW)
// =====================================================
else if (logpoint === 'RESPONSE_TO_CLIENT') {
    data.status_code = getVar('response.status.code');
    data.reason_phrase = getVar('response.reason.phrase');

    data.headers = getHeaders('response');
    data.payload_size = getContentLength('response');
    var payload4 = getPayload('response');
    if (payload4 !== undefined) data.payload = payload4;

    data.client_sent_start_timestamp = getVar('client.sent.start.timestamp');
    data.client_sent_end_timestamp = getVar('client.sent.end.timestamp');
}

// =====================================================
// ERROR CAPTURE (Safe Context Fallbacks)
// =====================================================
else if (logpoint === 'ERROR') {
    data.is_error = true;
    context.setVariable('is_error', true);
    
    data.fault_name = getVar('fault.name');
    data.fault_type = getVar('fault.type');
    data.fault_category = getVar('fault.category');
    data.fault_subcategory = getVar('fault.subcategory');
    data.fault_reason = getVar('fault.reason');
    data.error_message = getVar('error.message');
    data.error_status_code = getVar('error.status.code');
    data.error_reason_phrase = getVar('error.reason.phrase');
    data.error_transport_message = getVar('error.transport.message');
    data.error_state = getVar('error.state');

    var errorContent = getVar('error.content');
    if (errorContent) {
        var errStr = String(errorContent);
        if (errStr.length > MAX_PAYLOAD_SIZE) {
            data.error_content = errStr.substring(0, MAX_PAYLOAD_SIZE);
            data.error_content_truncated = true;
        } else {
            data.error_content = errStr;
            data.error_content_truncated = false;
        }
    }

    // According to the referenced docs, 'request'/'response' variables go out of scope 
    // in error pipelines. Use 'message' to safely capture surviving headers.
    data.headers = getHeaders('message');
    data.status_code = getVar('response.status.code') || getVar('error.status.code');
    data.reason_phrase = getVar('response.reason.phrase') || getVar('error.reason.phrase');
}

// --- Output saved to flow variables dynamically ---
context.setVariable('logging.data.' + logpoint, JSON.stringify(data));