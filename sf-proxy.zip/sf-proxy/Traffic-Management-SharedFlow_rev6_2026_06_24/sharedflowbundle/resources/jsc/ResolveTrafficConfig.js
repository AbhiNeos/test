/**
 * ResolveTrafficConfig.js - Two-Tier Edition
 * Sets variables for both API-Level safety and App-Contract-Level granular enforcement.
 * Legacy apiproduct precedence is removed.
 */

// --- TIER 1: API LEVEL (From PreFlightCheck KVM) ---
context.setVariable("traffic.api.quota.limit", context.getVariable("config.traffic.quota.limit") || "1000");
context.setVariable("traffic.api.quota.interval", context.getVariable("config.traffic.quota.interval") || "1");
context.setVariable("traffic.api.quota.timeunit", context.getVariable("config.traffic.quota.timeUnit") || "minute");
context.setVariable("traffic.api.spikearrest.rate", context.getVariable("config.traffic.spikearrest.rate") || "100ps");

// --- TIER 2: CONTRACT LEVEL (From appContractConfig KVM) ---
var contractJson = context.getVariable("private.contract.config.json");
if (contractJson) {
    try {
        var contract = JSON.parse(contractJson);
        
        // Quota
        if (contract.quota) {
            context.setVariable("traffic.contract.quota.limit", contract.quota.limit);
            context.setVariable("traffic.contract.quota.interval", contract.quota.interval);
            context.setVariable("traffic.contract.quota.timeunit", contract.quota.timeUnit || "minute");
        }
        
        // Spike Arrest
        if (contract.spikeArrest && contract.spikeArrest.rate) {
            context.setVariable("traffic.contract.spikearrest.rate", contract.spikeArrest.rate);
        }
        
        context.setVariable("traffic.contract.found", "true");
    } catch (e) {
        context.setVariable("traffic.contract.error", "Invalid JSON in contract config");
        context.setVariable("traffic.contract.found", "false");
    }
} else {
    context.setVariable("traffic.contract.found", "false");
}
