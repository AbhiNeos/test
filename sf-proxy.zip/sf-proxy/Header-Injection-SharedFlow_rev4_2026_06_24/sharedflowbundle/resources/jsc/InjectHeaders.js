/**
 * InjectHeaders.js
 * Injects headers into the request or response based on the current message direction.
 * Resolves templates like {trace_id} automatically.
 */

var direction = context.getVariable("message.dir");

// Fallback logic if message.dir is unresolved in the Shared Flow context
if (!direction || direction === "") {
    direction = (context.getVariable("response.status.code") !== null) ? "response" : "request";
}

var mapVarName = "config.headers." + direction + "_map";
var mapJson = context.getVariable(mapVarName);

if (mapJson) {
    try {
        var headerMap = JSON.parse(mapJson);

        for (var headerName in headerMap) {
            var value = headerMap[headerName];

            // Resolve templates: replace {var_name} with context.getVariable("var_name")
            if (value && value.indexOf("{") > -1) {
                value = value.replace(/\{(.+?)\}/g, function(match, varName) {
                    var resolved = context.getVariable(varName);
                    return (resolved !== null && resolved !== undefined) ? resolved : match;
                });
            }

            // Set the header in the current message (request or response)
            context.setVariable(direction + ".header." + headerName, value);
        }
    } catch (e) {
        // Log error to a variable if parsing fails, but don't break the flow
        context.setVariable("flow.header_injection.error", e.message);
    }
}
