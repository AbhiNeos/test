var incomingDN = context.getVariable("request.header.X-SSLClientCertDN");
var tokenDN = context.getVariable("jwt.JWT-VerifyToken.claim.X-SSLClientCertDN");

function throwTokenBindingError() {

    context.setVariable("token.binding.failed", true);

    context.setVariable(
        "token.binding.error",
        '{"Code":"401 Unauthorized","Id":"65b567cb-ec6c-49a5-9755-154bbbd65c","Message":"Token Binding Failed","Errors":[{"ErrorCode":"UK.OBIE.Token.Binding","Message":"The Token is Bound to another TLS Certificate","Path":"","Url":"https://openbanking.atlassian.net/wiki/spaces/DZ/pages/1000702294/Read+Write+Data+API+Specification+-+v3.1.1"}]}'
    );

    throw new Error("Token Binding Failed");
}

if (!incomingDN || !tokenDN) {
    throwTokenBindingError();
}

function parseDN(dn) {

    var result = {};

    var parts = dn.split(",");

    for (var i = 0; i < parts.length; i++) {

        var part = parts[i].trim();

        var idx = part.indexOf("=");

        if (idx > 0) {

            var key = part.substring(0, idx).trim();
            var value = part.substring(idx + 1).trim();

            result[key] = value;
        }
    }

    return result;
}

var incoming = parseDN(incomingDN);
var token = parseDN(tokenDN);

var areEqual = true;

if (incoming["CN"] !== token["CN"]) {
    areEqual = false;
}

if (
    incoming["2.5.4.97"] &&
    token["2.5.4.97"] &&
    incoming["2.5.4.97"] !== token["2.5.4.97"]
) {
    areEqual = false;
}

if (!areEqual) {
    throwTokenBindingError();
}