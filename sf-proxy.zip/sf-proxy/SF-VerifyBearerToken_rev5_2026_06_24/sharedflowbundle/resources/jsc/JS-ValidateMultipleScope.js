try {

    // -------------------------------------------------------------
    // Product scopes from VerifyAPIKey
    // Example:
    // AIApplication,accounts,agent,openid
    // -------------------------------------------------------------
    var productScopesStr = context.getVariable(
        "verifyapikey.VA-VerifyAPIKey.apiproduct.scopes"
    );

    // -------------------------------------------------------------
    // JWT scp claim
    // Can be:
    // agent
    // [agent]
    // [agent,accounts]
    // -------------------------------------------------------------
    var jwtScopes = context.getVariable(
        "jwt.JWT-VerifyToken.claim.scp"
    );

    if (!productScopesStr) {
        throw new Error("PRODUCT_SCOPES_NOT_FOUND");
    }

    if (!jwtScopes) {
        throw new Error("SCOPE_NOT_FOUND");
    }

    // -------------------------------------------------------------
    // Product Scopes
    // -------------------------------------------------------------
    var productScopes = productScopesStr
        .split(",")
        .map(function(scope) {
            return scope.trim();
        });

    // -------------------------------------------------------------
    // Parse JWT scp claim
    // -------------------------------------------------------------
    var tokenScopes = [];

    jwtScopes = String(jwtScopes).trim();

    if (
        jwtScopes.charAt(0) === "[" &&
        jwtScopes.charAt(jwtScopes.length - 1) === "]"
    ) {

        tokenScopes = jwtScopes
            .substring(1, jwtScopes.length - 1)
            .split(",");

    } else {

        tokenScopes = [jwtScopes];
    }

    // Cleanup values
    for (var i = 0; i < tokenScopes.length; i++) {
        tokenScopes[i] = tokenScopes[i]
            .replace(/"/g, "")
            .trim();
    }

    // -------------------------------------------------------------
    // Validate scopes
    // -------------------------------------------------------------
    var invalidScopes = [];

    for (var j = 0; j < tokenScopes.length; j++) {

        if (productScopes.indexOf(tokenScopes[j]) === -1) {
            invalidScopes.push(tokenScopes[j]);
        }
    }

    // -------------------------------------------------------------
    // Fail if invalid scope found
    // -------------------------------------------------------------
    if (invalidScopes.length > 0) {

        context.setVariable(
            "scope.validation.invalid",
            invalidScopes.join(",")
        );

        throw new Error(
            "INVALID_SCOPE: " + invalidScopes.join(",")
        );
    }

    context.setVariable("scope.validation.failed", false);
    context.setVariable("scope.validation.result", "success");

} catch (e) {

    context.setVariable("scope.validation.failed", true);
    context.setVariable("scope.validation.result", "failed");
    context.setVariable("scope.validation.error", e.message);

    context.setVariable("fault.name", "InvalidScope");
    context.setVariable(
        "fault.reason",
        "JWT contains scopes not permitted by API Product"
    );

    throw e;
}