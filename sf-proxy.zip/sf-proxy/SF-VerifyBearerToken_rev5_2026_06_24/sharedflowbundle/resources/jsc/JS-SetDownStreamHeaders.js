try {

    // Read decoded JWT payload
    var payloadStr = context.getVariable("jwt.JWT-VerifyToken.payload-json");

    if (!payloadStr) {
        throw new Error("Decoded JWS payload not found");
    }

    var payload = JSON.parse(payloadStr);

    // ==========================
    // client_id Mapping
    // ==========================

    var client_id = payload.client_id;

    if (client_id) {
        context.setVariable("request.header.OAuth_ClientID", client_id);
        context.setVariable("request.header.OAuth_ResourceOwnerUID", client_id);
    }

    // ==========================
    // Scope Mapping
    // ==========================

    var scopeValue = payload.scp;
    var scopeString = "";

    if (scopeValue) {

        // Scope as array
        if (Array.isArray(scopeValue)) {

            scopeString = scopeValue.join(" ");

        // Scope as string
        } else if (typeof scopeValue === "string") {

            scopeString = scopeValue;

        // Scope as object
        } else if (typeof scopeValue === "object") {

            var scopes = [];

            for (var key in scopeValue) {
                if (scopeValue.hasOwnProperty(key)) {
                    scopes.push(key + "=" + scopeValue[key]);
                }
            }

            scopeString = scopes.join(" ");
        }

        context.setVariable("request.header.OAuth_Scope", scopeString);
    }

} catch (e) {

    context.setVariable("js.error", e.toString());

    throw new Error("Failed to process JWT payload: " + e);
}