/**
 * ParseProxyConfig.js
 *
 * Parses the KVM-retrieved JSON and flattens it into context variables.
 *
 * KVM schema (all known fields):
 * {
 *   "space": "BUSpaceName",
 *   "flags": {
 *     "headerInjection": true, "cors": true, "auth": true,
 *     "securityFilters": true, "apiTrafficManagement": true, "specValidation": true,
 *     "jwsVerify": true, "jwsGenerate": true,
 *     "requestDecryption": true, "responseEncryption": true
 *   },
 *   "privateKeyIdentifier": ["space", "client", "proxy"],
 *   "authType":             ["encryptedJWT", "basic", "bindingJWT", "apikey"],
 *   "jws": { "algorithm": "PS256", "type": "CompactSerialization" },
 *   "jwe": { "Key": "", "content": "" },
 *   "traffic": {
 *     "quota":       { "limit": 100, "interval": "1", "timeUnit": "minute" },
 *     "spikeArrest": { "rate": "100ps" }
 *   },
 *   "headers": {
 *     "target.request": { ... },
 *     "api.response":   { ... }
 *   },
 *   "target": {
 *     "basepath": "/", "alternateTargetHost": "",
 *     "targetHost": "", "targetAuth": "TX+MTLS"
 *   }
 * }
 *
 * Null-handling rule:
 *   Any scalar value that is null, undefined, or an empty string ("") is stored as null.
 *
 * Array-handling rule (same as authType):
 *   Each element in the array is set as a boolean true flag on the parent key.
 *   e.g. privateKeyIdentifier: ["space","client"] →
 *        config.privateKeyIdentifier.space  = true
 *        config.privateKeyIdentifier.client = true
 *        config.privateKeyIdentifier.proxy  = false   (known value not in array)
 *        config.privateKeyIdentifier.list   = "space,client"
 */

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Normalise a scalar value:
 *   - null / undefined / "" → null
 *   - everything else       → as-is
 */
function normalise(val) {
    if (val === null || val === undefined || val === "") {
        return null;
    }
    return val;
}

/**
 * Expand a string array into individual boolean flags under a namespace prefix.
 * All known values are pre-set to false, then only the present ones are set to true.
 * A comma-separated list is also stored as <prefix>.list
 *
 * @param {string[]} arr        - the array from KVM
 * @param {string}   prefix     - context variable prefix  (e.g. "config.flags.authType")
 * @param {string[]} knownValues - exhaustive list of valid values for this array
 */
function expandArrayFlags(arr, prefix, knownValues) {
    // Pre-set all known values to false
    for (var k = 0; k < knownValues.length; k++) {
        context.setVariable(prefix + "." + knownValues[k], false);
    }
    // Enable only the ones actually present
    for (var i = 0; i < arr.length; i++) {
        var item = arr[i];
        if (item) {
            context.setVariable(prefix + "." + item, true);
        }
    }
    // Convenience list
    context.setVariable(prefix + ".list", arr.join(","));
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

try {
    var configJson = context.getVariable("private.proxy.config.json");

    if (configJson) {
        var config = JSON.parse(configJson);

        // ===================================================================
        // 0. Top-level scalar: space
        // ===================================================================
        context.setVariable("config.space", normalise(config.space));

        // ===================================================================
        // 1. Flags — flatten to booleans
        //    Any flag not present in the KVM is left unset (defaults to false
        //    in Apigee condition evaluation).
        // ===================================================================
        var knownFlags = [
            "headerInjection", "cors", "auth",
            "securityFilters", "apiTrafficManagement", "specValidation",
            "jwsVerify", "jwsGenerate",
            "requestDecryption", "responseEncryption"
        ];

        if (config.flags) {
            for (var f = 0; f < knownFlags.length; f++) {
                var flagName = knownFlags[f];
                var flagVal  = config.flags[flagName];
                context.setVariable("config.flags." + flagName,
                    (flagVal === true || flagVal === "true"));
            }
        }

        // ===================================================================
        // 2. authType array → config.flags.authType.<value> = true/false
        //    Only expanded when auth flag is true.
        // ===================================================================
        var knownAuthTypes = ["oauth", "basic", "jwt", "apikey", "encryptedJWT", "bindingJWT"];

        if (config.flags && config.flags.auth === true && Array.isArray(config.authType) && config.authType.length > 0) {
            expandArrayFlags(config.authType, "config.flags.authType", knownAuthTypes);
        } else {
            // Auth disabled or no authType — set all to false for clean state
            for (var a = 0; a < knownAuthTypes.length; a++) {
                context.setVariable("config.flags.authType." + knownAuthTypes[a], false);
            }
            context.setVariable("config.flags.authType.list", "");
        }

        // ===================================================================
        // 3. privateKeyIdentifier array → config.privateKeyIdentifier.<value> = true/false
        // ===================================================================
        var knownKeyIdentifiers = ["space", "client", "proxy"];

        if (Array.isArray(config.privateKeyIdentifier) && config.privateKeyIdentifier.length > 0) {
            expandArrayFlags(config.privateKeyIdentifier, "config.privateKeyIdentifier", knownKeyIdentifiers);
        } else {
            for (var p = 0; p < knownKeyIdentifiers.length; p++) {
                context.setVariable("config.privateKeyIdentifier." + knownKeyIdentifiers[p], false);
            }
            context.setVariable("config.privateKeyIdentifier.list", "");
        }

        // ===================================================================
        // 4. JWS settings
        //    config.jws.algorithm  e.g. "PS256"
        //    config.jws.type       e.g. "CompactSerialization"
        // ===================================================================
        if (config.jws) {
            context.setVariable("config.jws.algorithm", normalise(config.jws.algorithm));
            context.setVariable("config.jws.type",      normalise(config.jws.type));
        } else {
            context.setVariable("config.jws.algorithm", null);
            context.setVariable("config.jws.type",      null);
        }

        // ===================================================================
        // 5. JWE settings
        //    config.jwe.Key      — encryption key (may be empty → null)
        //    config.jwe.content  — content encryption algorithm (may be empty → null)
        // ===================================================================
        if (config.jwe) {
            context.setVariable("config.jwe.key",     normalise(config.jwe.Key));
            context.setVariable("config.jwe.content", normalise(config.jwe.content));
        } else {
            context.setVariable("config.jwe.key",     null);
            context.setVariable("config.jwe.content", null);
        }

        // ===================================================================
        // 6. Traffic settings
        // ===================================================================
        if (config.traffic) {
            if (config.traffic.quota) {
                context.setVariable("config.traffic.quota.limit",    normalise(config.traffic.quota.limit));
                context.setVariable("config.traffic.quota.interval", normalise(config.traffic.quota.interval));
                context.setVariable("config.traffic.quota.timeUnit", normalise(config.traffic.quota.timeUnit));
            }
            if (config.traffic.spikeArrest) {
                context.setVariable("config.traffic.spikearrest.rate", normalise(config.traffic.spikeArrest.rate));
            }
        }

        // ===================================================================
        // 7. Headers
        // ===================================================================
        if (config.headers) {
            // target.request headers — forwarded to the backend
            var reqHeaders = config.headers["target.request"] || config.headers.request;
            if (reqHeaders) {
                context.setVariable("config.headers.request_map", JSON.stringify(reqHeaders));
                for (var reqHdr in reqHeaders) {
                    context.setVariable("config.headers.request." + reqHdr, normalise(reqHeaders[reqHdr]));
                }
            }

            // api.response headers — added to the gateway response
            var respHeaders = config.headers["api.response"] || config.headers.response;
            if (respHeaders) {
                context.setVariable("config.headers.response_map", JSON.stringify(respHeaders));
                for (var respHdr in respHeaders) {
                    context.setVariable("config.headers.response." + respHdr, normalise(respHeaders[respHdr]));
                }
            }
        }

        // ===================================================================
        // 8. Target configuration
        // ===================================================================
        if (config.target) {
            context.setVariable("config.target.basepath",            normalise(config.target.basepath)            || "/");
            context.setVariable("config.target.targetHost",          normalise(config.target.targetHost));
            context.setVariable("config.target.alternateTargetHost", normalise(config.target.alternateTargetHost));
            context.setVariable("config.target.targetAuth",          normalise(config.target.targetAuth)          || "NoAUTH");
        }

        context.setVariable("config.loaded", "true");

    } else {
        context.setVariable("config.loaded", "false");
        context.setVariable("config.error",  "KVM value 'private.proxy.config.json' is empty or not set.");
    }

} catch (e) {
    context.setVariable("config.error",  e.message);
    context.setVariable("config.loaded", "false");
}
