/**
 * EvaluateError.js
 *
 * Evaluates the fault/error context and builds a standardised error response.
 * Enhanced to automatically handle pass-through and conditional 5XX overrides 
 * when attached to a TargetEndpoint vs a ProxyEndpoint inside a Shared Flow.
 *
 * RAISEFAULT HANDLING:
 * When a RaiseFault policy fires:
 *   - fault.name = "RaiseFault" (always, regardless of policy name)
 *   - error.message = "Raising fault. Fault name : RF-PolicyName"
 * 
 * This script parses the actual policy name from error.message and uses THAT
 * as the switch key, so each RF-* policy maps to its own error response.
 *
 * To add a new RaiseFault error:
 *   1. Create a RaiseFault policy named "RF-YourNewError" in the proxy
 *   2. Add a case "RF-YourNewError" in the switch block below
 *   3. No other wiring needed — the shared flow auto-detects it
 */

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function generateErrorId() {
    var msgId = context.getVariable("message.id");
    if (msgId) { return msgId; }
    var ts  = (new Date()).getTime().toString(16);
    var rnd = Math.floor(Math.random() * 0xFFFFFF).toString(16);
    return ts + "-" + rnd;
}

function setFault(status, phrase, topMessage, errorCode, errorMessage, path, url) {
    var body = {
        Code:    status + " " + phrase,
        Id:      generateErrorId(),
        Message: topMessage,
        Errors: [
            {
                ErrorCode: errorCode,
                Message:   errorMessage,
                Path:      path || "",
                Url:       url  || ""
            }
        ]
    };

    context.setVariable("custom.error.status", status);
    context.setVariable("custom.error.phrase",  phrase);
    context.setVariable("custom.error.code",    errorCode);
    context.setVariable("custom.error.body",    JSON.stringify(body, null, 2));
}

// ---------------------------------------------------------------------------
// Context-Aware Scope Evaluation (Target vs Proxy Routing Rules)
// ---------------------------------------------------------------------------
var flowState = String(context.getVariable("currentstep.flowstate") || "");
var rawStatus = parseInt(context.getVariable("error.status.code") || context.getVariable("response.status.code"), 10) || 500;

var isTargetFlow = (flowState === "TARGET_RESP_FLOW" || flowState === "TARGET_REQ_FLOW");

// RULE: If triggered by Target and it is NOT a 5XX error, bypass the framework and pass-through raw
if (isTargetFlow && rawStatus < 500) {
    context.setVariable("custom.error.bypass_framework", true);
} 
// RULE: If triggered by Target and it IS a 5XX error, overwrite with "Service Temporarily Out Of Service"
else if (isTargetFlow && rawStatus >= 500) {
    setFault(
        503, "Service Unavailable",
        "The upstream service is experiencing issues.",
        "UK.OBIE.Upstream.Down",
        "The backend service is temporarily out of service. Please try your request again later.",
        "Upstream",
        ""
    );
} 
// Otherwise, execute the standard internal Proxy Error evaluation block
else {

    // -----------------------------------------------------------------------
    // RESOLVE FAULT NAME
    //
    // For most policies, fault.name = the specific fault (e.g. "InvalidAccessToken")
    // For RaiseFault policies, fault.name = "RaiseFault" ALWAYS.
    // To identify WHICH RaiseFault fired, parse error.message:
    //   "Raising fault. Fault name : RF-CustomError"
    // -----------------------------------------------------------------------

    var rawFaultName = context.getVariable("fault.name") || "";
    var errorMessage = context.getVariable("error.message") || "";
    var faultName    = "";

    if (rawFaultName === "RaiseFault" && errorMessage.indexOf("Fault name : ") !== -1) {
        // Extract the policy name after "Fault name : "
        var parts = errorMessage.split("Fault name : ");
        if (parts.length > 1) {
            faultName = parts[1].trim();
        }
    } else {
        // Non-RaiseFault policies: use fault.name directly
        faultName = context.getVariable("custom.error.fault_name") || rawFaultName;
    }

    switch (faultName) {

        // ===================================================================
        // RAISEFAULT POLICIES (parsed from error.message)
        // Add new RF-* cases here. Each maps to a specific error response.
        // ===================================================================

        case "RF-InvalidBasicAuthCredentials":
            setFault(
                401, "Unauthorized",
                "Authentication credentials are missing or invalid.",
                "UK.OBIE.Auth.InvalidCredentials",
                "The provided client_id or client_secret does not match a registered application.",
                "Authentication",
                ""
            );
            break;

        case "RF-InvalidAPIKey":
            setFault(
                401, "Unauthorized",
                "Authentication credentials are missing or invalid.",
                "UK.OBIE.Auth.InvalidApiKey",
                "The API key provided is missing or invalid.",
                "Authentication",
                ""
            );
            break;

        case "RF-TriggerOASError":
        case "OASValidationFailure":
        case "OASValidationFailed":
            // Handles native OAS validation faults (continueOnError="false" on OASValidation policy)
            // Parses the OAS validation fault cause to extract a human-readable reason.
            var oasFaultCause = context.getVariable("OASValidation.OAS-SpecValidation.fault.cause") ||
                                context.getVariable("fault.cause") ||
                                context.getVariable("error.message") ||
                                "Unknown validation error";
            var oasReason = oasFaultCause;

            // Format: "... failed with reason: \"[ERROR - <REASON>: []]\""
            var oasMatch = oasFaultCause.match(/failed with reason: \"\[ERROR - (.*?): \[\]\]\"/);
            if (oasMatch && oasMatch[1]) {
                oasReason = oasMatch[1];
            } else {
                // Fallback cleanup
                oasReason = oasReason.replace(/\[ERROR - /, "").replace(/: \[\]\]/, "");
            }

            setFault(
                400, "Bad Request",
                "The request does not conform to the API specification.",
                "UK.OBIE.Field.OASValidation",
                oasReason,
                "OAS Validation",
                ""
            );
            break;

        case "RF-InvalidMethodError":
            setFault(
                404, "Not Found",
                "The requested resource or HTTP method could not be found.",
                "UK.OBIE.Resource.NotFound",
                "No service was found for the requested HTTP method and path combination.",
                "Routing",
                ""
            );
            break;

        // ── Add your new RaiseFault cases below this line ──────────────────
        // 
        // case "RF-YourNewError":
        //     setFault(
        //         <status>, "<phrase>",
        //         "<top-level message>",
        //         "<error code>",
        //         "<detailed message>",
        //         "<path>",
        //         "<url>"
        //     );
        //     break;
        //
        // ───────────────────────────────────────────────────────────────────


        // ===================================================================
        // SYSTEM FAULTS (fault.name from Apigee policies like OAuth, JWT, etc.)
        // ===================================================================

        // --- AUTHENTICATION — 401 Unauthorized ---

        case "FailedToResolveAccessToken":
        case "FailedToResolveToken":
        case "FailedToResolveAuthorizationCode":
        case "InvalidAccessToken":
        case "access_token_expired":
        case "invalid_access_token":
        case "InvalidOperation":
            setFault(
                401, "Unauthorized",
                "Authentication credentials are missing or invalid.",
                "UK.OBIE.Auth.InvalidToken",
                "The Bearer token is missing, expired, or invalid.",
                "Authentication",
                ""
            );
            break;

        case "TokenExpired":
            setFault(
                401, "Unauthorized",
                "Authentication credentials are missing or invalid.",
                "UK.OBIE.Auth.TokenExpired",
                "The JWT token has expired. Please obtain a new token and retry.",
                "Authentication",
                ""
            );
            break;

        case "InvalidJWT":
        case "BadJOSEHeader":
        case "AlgorithmNotAllowed":
        case "InvalidJWTAlgorithm":
            setFault(
                401, "Unauthorized",
                "Authentication credentials are missing or invalid.",
                "UK.OBIE.Auth.InvalidToken",
                "The JWT token is malformed or uses an unsupported algorithm. Expected RS256.",
                "Authentication",
                ""
            );
            break;

        case "InvalidClaim":
        case "FailedToResolveClaim":
            setFault(
                401, "Unauthorized",
                "Authentication credentials are missing or invalid.",
                "UK.OBIE.Auth.InvalidClaim",
                "The JWT token contains an invalid or missing claim (issuer, audience, or custom claim).",
                "Authentication",
                ""
            );
            break;

        case "JWKSFetchFailed":
        case "JWKSResponseUnexpected":
            setFault(
                502, "Bad Gateway",
                "An error occurred while validating the token.",
                "UK.OBIE.Auth.JWKSUnavailable",
                "The JWKS endpoint could not be reached to verify the token signature. Please retry.",
                "Authentication",
                ""
            );
            break;

        case "DecryptionFailed":
        case "JWEDecryptionFailed":
            setFault(
                401, "Unauthorized",
                "Authentication credentials are missing or invalid.",
                "UK.OBIE.Auth.DecryptionFailed",
                "The encrypted JWT (JWE) token could not be decrypted. Ensure the correct encryption key is used.",
                "Authentication",
                ""
            );
            break;

        case "FailedToResolveAPIKey":
        case "InvalidApiKey":
        case "InvalidAPIKey":
            setFault(
                401, "Unauthorized",
                "Authentication credentials are missing or invalid.",
                "UK.OBIE.Auth.InvalidApiKey",
                "The API key provided in the Authorization header is missing or invalid.",
                "Authentication",
                ""
            );
            break;

        // --- AUTHORIZATION — 403 Forbidden ---

        case "ApiKeyNotApproved":
        case "app_not_approved":
            setFault(
                403, "Forbidden",
                "Access to this resource is forbidden.",
                "UK.OBIE.Auth.NotApproved",
                "The API key or application has not been approved for access.",
                "Authorization",
                ""
            );
            break;

        case "CompanyStatusNotActive":
        case "DeveloperStatusNotActive":
            setFault(
                403, "Forbidden",
                "Access to this resource is forbidden.",
                "UK.OBIE.Auth.AccountInactive",
                "The developer or company account associated with this credential is inactive.",
                "Authorization",
                ""
            );
            break;

        case "InvalidApiKeyForGivenResource":
        case "InvalidAPICallAsNoApiProductMatchFound":
            setFault(
                403, "Forbidden",
                "Access to this resource is forbidden.",
                "UK.OBIE.Auth.ResourceForbidden",
                "The API key is not authorised to access this resource or API product.",
                "Authorization",
                ""
            );
            break;

        // --- TRAFFIC MANAGEMENT — 429 Too Many Requests ---

        case "SpikeArrestViolation":
        case "InvalidMessageWeight":
        case "ErrorLoadingProperties":
        case "FailedToResolveSpikeArrestRate":
            setFault(
                429, "Too Many Requests",
                "The request rate limit has been exceeded.",
                "UK.OBIE.Traffic.SpikeArrest",
                "The spike arrest threshold has been breached. Please reduce your request rate and retry.",
                "Traffic Management",
                ""
            );
            break;

        case "QuotaViolation":
        case "InvalidQuotaInterval":
        case "InvalidQuotaTimeUnit":
        case "FailedToResolveQuotaIntervalReference":
        case "FailedToResolveQuotaIntervalTimeUnitReference":
            setFault(
                429, "Too Many Requests",
                "The request quota has been exceeded.",
                "UK.OBIE.Traffic.QuotaExceeded",
                "You have exceeded your allocated request quota. Please retry after the quota window resets.",
                "Traffic Management",
                ""
            );
            break;

        // --- SECURITY / VALIDATION ---

        case "ThreatDetected":
        case "ExceededContainerDepth":
        case "ExceededObjectEntryCount":
        case "ExceededArrayElementCount":
        case "ExceededObjectEntryNameLength":
        case "ExceededStringValueLength":
            setFault(
                400, "Bad Request",
                "The request was rejected by the security filter.",
                "UK.OBIE.Security.ThreatDetected",
                "The request payload failed security inspection. It may contain a threat pattern or exceed allowed structural limits.",
                "Security",
                ""
            );
            break;

        case "SourceUnavailable":
        case "NonMessageVariable":
        case "ExecutionFailed":
            setFault(
                400, "Bad Request",
                "The request could not be processed.",
                "UK.OBIE.Field.Invalid",
                "The request is malformed or a required message component could not be resolved.",
                "Request",
                ""
            );
            break;

        case "ErrorResponseCode":
            var backendStatus = parseInt(context.getVariable("error.status.code"), 10) || 502;
            var backendPhrase = context.getVariable("error.status.phrase") || "Bad Gateway";
            
            if (backendStatus >= 500) {
                setFault(
                    503, "Service Unavailable",
                    "The upstream service is experiencing issues.",
                    "UK.OBIE.Upstream.Down",
                    "The backend service is temporarily out of service. Please try your request again later.",
                    "Upstream",
                    ""
                );
            } else {
                setFault(
                    backendStatus, backendPhrase,
                    "An error was returned by the upstream service.",
                    "UK.OBIE.Upstream.Error",
                    backendPhrase,
                    "Upstream",
                    ""
                );
            }
            break;
    }

    // -----------------------------------------------------------------------
    // DEFAULT CATCH-ALL
    // -----------------------------------------------------------------------
    if (!context.getVariable("custom.error.code")) {
        setFault(
            500, "Internal Server Error",
            "An unexpected error occurred. Please contact support if the problem persists.",
            "UK.OBIE.Unexpected.Error",
            "An internal server error occurred. Fault: " + (faultName || "unknown"),
            "Request",
            ""
        );
    }
}
