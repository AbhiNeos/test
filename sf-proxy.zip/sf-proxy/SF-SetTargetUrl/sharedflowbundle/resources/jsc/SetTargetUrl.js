/**
 * SetTargetUrl.js
 *
 * Dynamically sets the target URL based on KVM config values parsed by
 * PreFlight-Check-SharedFlow and an optional request header override.
 *
 * Config variables (set by JS-ParseProxyConfig in PreFlight-Check):
 *   config.target.targetHost          - Primary backend host (e.g. "httpbin.org")
 *   config.target.alternateTargetHost - Alternate backend host (e.g. "mocktarget.apigee.net")
 *   config.target.basepath            - Path appended to host (e.g. "/ip")
 *   config.target.targetAuth          - Auth mode hint (e.g. "TX/NoAUTH/MTLS")
 *
 * Routing Rules:
 *   1. If request header "X-Target-Host" = "alternate" → use alternateTargetHost
 *   2. Otherwise → use targetHost (default primary backend)
 *   3. Final URL = "https://" + selectedHost + basepath
 *
 * Sets:
 *   target.url - The resolved backend URL (Apigee uses this to override HTTPTargetConnection)
 */

// ---------------------------------------------------------------------------
// Read config values
// ---------------------------------------------------------------------------
var targetHost          = context.getVariable("config.target.targetHost") || "";
var alternateTargetHost = context.getVariable("config.target.alternateTargetHost") || "";
var basepath            = context.getVariable("config.target.basepath") || "/";

// ---------------------------------------------------------------------------
// Determine which host to use
// ---------------------------------------------------------------------------
var hostOverrideHeader = (context.getVariable("request.header.X-Target-Host") || "").toLowerCase().trim();

var selectedHost = targetHost; // default

if (hostOverrideHeader === "alternate" && alternateTargetHost) {
    selectedHost = alternateTargetHost;
}

// ---------------------------------------------------------------------------
// Guard: ensure we have a valid host
// ---------------------------------------------------------------------------
if (!selectedHost) {
    // Fallback: leave target.url unchanged (use HTTPTargetConnection default)
    context.setVariable("target.url.resolved", "false");
    context.setVariable("target.url.error", "No targetHost or alternateTargetHost configured in KVM.");
} else {
    // ---------------------------------------------------------------------------
    // Build the final URL
    // ---------------------------------------------------------------------------

    // Ensure basepath starts with /
    if (basepath.charAt(0) !== "/") {
        basepath = "/" + basepath;
    }

    // Remove trailing slash from host if present
    if (selectedHost.charAt(selectedHost.length - 1) === "/") {
        selectedHost = selectedHost.substring(0, selectedHost.length - 1);
    }

    // Strip protocol if someone accidentally included it in KVM
    if (selectedHost.indexOf("https://") === 0) {
        selectedHost = selectedHost.substring(8);
    } else if (selectedHost.indexOf("http://") === 0) {
        selectedHost = selectedHost.substring(7);
    }

    var targetUrl = "https://" + selectedHost + basepath;

    // Set the Apigee target.url variable (overrides HTTPTargetConnection URL)
    context.setVariable("target.url", targetUrl);
    context.setVariable("target.url.resolved", "true");
    context.setVariable("target.url.host", selectedHost);
    context.setVariable("target.url.basepath", basepath);
}
